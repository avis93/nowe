﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using AForge.Controls;
using AForge.Video.DirectShow;
using System.Windows.Forms;
using AForge.Video;
using System.Drawing.Imaging;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {

        int fps;
        Bitmap bmp = (Bitmap)Image.FromFile("c:/users/student/Polish_tv_rating_system_bo_2011.png");



        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            FileVideoSource fileVideo = new FileVideoSource("C:/Users/student/downloads/film1.avi");
            fileVideo.Start();
            videoSourcePlayer1.VideoSource = fileVideo;
        }

        private unsafe void videoSourcePlayer1_NewFrame(object sender, ref Bitmap image)
        {
            BitmapData bm = bmp.LockBits(new Rectangle(Point.Empty, bmp.Size), ImageLockMode.ReadWrite, bmp.PixelFormat);
            UInt32* ptr = (UInt32*)bm.Scan0.ToPointer();

            

            fps++;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label1.Text = fps.ToString();
            fps = 0;
        }
    }

}
